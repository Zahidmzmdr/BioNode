# BioNode

AI-controlled BioCNG micro-refinery — converts water hyacinth and other waste
feedstocks into vehicle-grade compressed biomethane. Developed for BEAR
Summit 2026 (Bangladesh).

## ⚠️ Important: what is and isn't in this repo

**There is no embedded/firmware/PLC source code in this repository.**
No physical prototype has been coded yet — the digester, sensors, PLC
control loop, and Edge-AI inference described in `/docs/technical` are
**architecture specifications**, not implemented software. Nothing here
has been flashed to real hardware or tested on a physical unit.

What *is* real, working code:

- **`/simulation/dashboard.html`** — a self-contained, functional
  front-end simulation of the proposed AIoT control dashboard (sensor
  readouts, digestion stage tracking, simulated AI decision log). This
  is a demo/mockup for pitching and visualization, not a control system
  connected to any hardware.
- **`/simulation/presentation.html`** — an interactive HTML slide deck
  used for pitch presentations.

Everything else in `/docs` is written documentation: project briefs,
technical specs, wiring diagrams, form submissions, and pitch materials
produced during the BEAR Summit 2026 application process.

## Repo structure

```
/simulation
  dashboard.html       — interactive frontend simulation (open in any browser)
  presentation.html     — interactive slide deck (open in any browser)

/docs
  /brief                — project briefs, concept notes, vision materials
  /technical             — resubmission doc (system architecture spec),
                            wiring schematic (proposed, unbuilt)
  /media                 — presentation deck, video script, media guide
  BioNode_LinkedIn_Post_BEAR2026.txt
```

## Status as of last update

- System architecture: **designed, documented, not implemented in code**
- Physical prototype: **not built**
- Control software (PLC/embedded/AI inference): **not written**
- Frontend simulation: **built, functional, for demo purposes only**

## If you're picking this up

If anyone on the team has since written real PLC/embedded/firmware code
or built physical hardware, add it here under a new `/firmware` or
`/hardware` folder and update this README — as of this snapshot, none
exists.
